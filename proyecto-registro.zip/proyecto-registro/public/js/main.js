const usuario = {
    nombre: "Juan",
    edad: 25,
    email: "juan@ejemplo.com"
    };
    const usuarios = [
    { id: 1, nombre: "Ana" },
    { id: 2, nombre: "Carlos" }
    ];
    // Conversión y manipulación de datos
   